import math
import heapq
from typing import List, Tuple, Optional


def dijkstra(adj_matrix: List[List[Optional[float]]], source: int):
    """Run Dijkstra's algorithm on an adjacency matrix.

    adj_matrix: square matrix where adj_matrix[i][j] is the weight from i to j,
                or None/math.inf to indicate no edge.
    source: index of the source vertex (0-based)

    Returns: (distances, predecessors) where distances[i] is shortest distance
    from source to i (math.inf if unreachable) and predecessors[i] is the
    previous node on the shortest path (or None).
    """
    n = len(adj_matrix)
    dist = [math.inf] * n
    prev = [None] * n
    dist[source] = 0
    visited = [False] * n

    heap = [(0, source)]
    while heap:
        d, u = heapq.heappop(heap)
        if visited[u]:
            continue
        visited[u] = True
        for v in range(n):
            w = adj_matrix[u][v]
            if w is None:
                continue
            alt = d + w
            if alt < dist[v]:
                dist[v] = alt
                prev[v] = u
                heapq.heappush(heap, (alt, v))

    return dist, prev


def reconstruct_path(prev: List[Optional[int]], target: int) -> List[int]:
    """Reconstruct path from source to target using predecessors list."""
    path = []
    u = target
    while u is not None:
        path.append(u)
        u = prev[u]
    path.reverse()
    return path


def prim(adj_matrix: List[List[Optional[float]]], start: int = 0):
    """Prim's algorithm to compute a Minimum Spanning Tree (MST).

    Returns a list of edges (u, v, w) in the MST and the total cost.
    """
    n = len(adj_matrix)
    in_mst = [False] * n
    key = [math.inf] * n
    parent = [None] * n
    key[start] = 0

    for _ in range(n):
        # pick min key vertex not in MST
        u = None
        min_key = math.inf
        for v in range(n):
            if not in_mst[v] and key[v] < min_key:
                min_key = key[v]
                u = v
        if u is None:
            break
        in_mst[u] = True
        # update neighbors
        for v in range(n):
            w = adj_matrix[u][v]
            if w is None:
                continue
            if not in_mst[v] and w < key[v]:
                key[v] = w
                parent[v] = u

    edges = []
    total = 0
    for v in range(n):
        if parent[v] is not None:
            u = parent[v]
            w = adj_matrix[u][v]
            edges.append((u, v, w))
            total += w
    return edges, total


def adjacency_matrix_to_string(adj_matrix: List[List[Optional[float]]], labels=None) -> str:
    n = len(adj_matrix)
    if labels is None:
        labels = [str(i) for i in range(n)]
    # header
    hdr = '    ' + ' '.join(f'{lab:>5}' for lab in labels)
    rows = [hdr]
    for i in range(n):
        row = f'{labels[i]:>3} '
        for j in range(n):
            w = adj_matrix[i][j]
            if w is None:
                row += f'{"-":>6}'
            else:
                row += f'{str(w):>6}'
        rows.append(row)
    return '\n'.join(rows)


def build_adj_matrix_from_edges(n: int, edges: List[Tuple[int, int, float]], directed=False):
    """Build an n x n adjacency matrix from edges (u, v, w). Use None for no edge."""
    mat = [[None] * n for _ in range(n)]
    for u, v, w in edges:
        mat[u][v] = w
        if not directed:
            mat[v][u] = w
    return mat


if __name__ == '__main__':
    # Small example graph demonstration (replace with your adjacency matrix)
    labels = ['A', 'B', 'C', 'D']
    edges = [
        (0, 1, 1),
        (0, 2, 4),
        (1, 2, 2),
        (1, 3, 6),
        (2, 3, 3),
    ]
    mat = build_adj_matrix_from_edges(len(labels), edges)
    print('Adjacency matrix:')
    print(adjacency_matrix_to_string(mat, labels))
    dist, prev = dijkstra(mat, 0)
    print('\nDijkstra distances from A:')
    for lab, d in zip(labels, dist):
        print(f'  {lab}: {d}')
    path = reconstruct_path(prev, 3)
    print('Shortest path A->D (indices):', path)
    print('Edges in MST (Prim):', prim(mat))
