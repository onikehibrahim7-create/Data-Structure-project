# Data Structures & Algorithms - Project

This small Python project contains two tasks commonly given in data-structures courses:

- Tower of Hanoi (recursion)
- Binary Tree Traversals (preorder, inorder, postorder, level-order)

Files:

- `main.py` - CLI menu to run either task interactively.
- `tower_of_hanoi.py` - generate moves, simulate peg states, and pretty-print states.
- `tree_traversals.py` - `Node` class, traversal functions, and builder from level-order list.
- `test_run.py` - quick non-interactive checks.

Usage:

Run the interactive menu:

```powershell
python .\main.py
```

Run quick tests:

```powershell
python .\test_run.py
```


Default example tree used by the program (level-order):

Complete binary tree with nodes 1 to 31 (matches provided image):

```
                                1
                 /              \
             2                 3
         /   \             /   \
        4     5           6     7
     / \   / \         / \   / \
    8  9 10 11       12 13 14 15
 /\ /\ /\ /\      /\ /\ /\ /\
16.............31 (all leaves)
```

Traversals for this tree:

- Pre-order : 1 2 4 8 16 17 9 18 19 5 10 20 21 11 22 23 3 6 12 24 25 13 26 27 7 14 28 29 15 30 31
- In-order  : 16 8 17 4 18 9 19 2 20 10 21 5 22 11 23 1 24 12 25 6 26 13 27 3 28 14 29 7 30 15 31
- Post-order: 16 17 8 18 19 9 4 20 21 10 22 23 11 5 2 24 25 12 26 27 13 6 28 29 14 30 31 15 7 3 1
- Level-order: 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31

Tower of Hanoi:

The program prints each move and an ASCII-ish representation of pegs after each move when run.
