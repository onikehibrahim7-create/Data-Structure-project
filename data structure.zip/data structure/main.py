#!/usr/bin/env python3
from tower_of_hanoi import generate_hanoi_moves, simulate_hanoi_steps, pretty_print_state
from tree_traversals import (
	Node,
	build_tree_from_level_order,
	preorder,
	inorder,
	postorder,
	level_order,
)


def run_hanoi():
	try:
		n = int(input('Enter number of disks (n >= 1): ').strip())
	except ValueError:
		print('Invalid input')
		return
	moves, states = simulate_hanoi_steps(n)
	print(f"Total moves: {len(moves)}")
	for i, ((frm, to), state) in enumerate(zip(moves, states[1:]), start=1):
		print(f"Move {i}: {frm} -> {to}")
		print(pretty_print_state(state))
		print()


def run_traversals():
	print('Enter tree as level-order values separated by space. Use _ or None for empty nodes')
	s = input('Example (press Enter for default tree): ').strip()
	if not s:
		lst = list(range(1, 32))
	else:
		parts = s.split()
		lst = [None if p in ('_', 'None') else p for p in parts]
	root = build_tree_from_level_order(lst)
	print('Tree (level-order):', lst)
	print('Pre-order :', ' '.join(map(str, preorder(root))))
	print('In-order  :', ' '.join(map(str, inorder(root))))
	print('Post-order:', ' '.join(map(str, postorder(root))))
	print('Level-order:', ' '.join(map(str, level_order(root))))


def main():
	while True:
		print('\nChoose an option:')
		print('1) Tower of Hanoi (recursion)')
		print('2) Tree traversals (pre,in,post,level)')
		print('0) Exit')
		choice = input('> ').strip()
		if choice == '1':
			run_hanoi()
		elif choice == '2':
			run_traversals()
		elif choice == '0':
			break
		else:
			print('Invalid choice')


if __name__ == '__main__':
	main()
