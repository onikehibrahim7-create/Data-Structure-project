import heapq


class HuffmanNode:
    def __init__(self, freq, symbol=None, left=None, right=None):
        self.freq = freq
        self.symbol = symbol
        self.left = left
        self.right = right

    def __lt__(self, other):
        # heapq needs comparison
        return self.freq < other.freq


def build_huffman_tree(freqs):
    """Build Huffman tree from dict of symbol->frequency.

    Returns (root, merge_steps) where merge_steps is a list of tuples
    (freq1, sym1, freq2, sym2, combined_freq) describing each merge.
    """
    heap = []
    counter = 0
    for sym, f in freqs.items():
        node = HuffmanNode(f, symbol=sym)
        heapq.heappush(heap, (f, counter, node))
        counter += 1

    merge_steps = []
    while len(heap) > 1:
        f1, _, n1 = heapq.heappop(heap)
        f2, _, n2 = heapq.heappop(heap)
        combined = HuffmanNode(f1 + f2, left=n1, right=n2)
        merge_steps.append((f1, n1.symbol, f2, n2.symbol, combined.freq))
        heapq.heappush(heap, (combined.freq, counter, combined))
        counter += 1

    root = heap[0][2] if heap else None
    return root, merge_steps


def generate_codes(root):
    codes = {}

    def _walk(node, prefix=''):
        if node is None:
            return
        if node.symbol is not None:
            codes[node.symbol] = prefix or '0'
            return
        _walk(node.left, prefix + '0')
        _walk(node.right, prefix + '1')

    _walk(root, '')
    return codes


def encoded_length(freqs, codes):
    """Return total encoded length in bits for the given freqs and codes."""
    return sum(freqs[sym] * len(codes[sym]) for sym in freqs)


def huffman_for_frequencies(freqs):
    root, merges = build_huffman_tree(freqs)
    codes = generate_codes(root)
    total_bits = encoded_length(freqs, codes)
    return codes, total_bits, merges


if __name__ == '__main__':
    freqs = {'a': 2, 'b': 4, 'c': 8, 'd': 16, 'e': 16}
    codes, total_bits, merges = huffman_for_frequencies(freqs)
    print('Given frequencies:')
    for s, f in freqs.items():
        print(f'  {s}: {f}')
    print('\nMerge steps (freq, symbol or None):')
    for step in merges:
        print('  merge', step)
    print('\nHuffman codes:')
    for s in sorted(codes):
        print(f'  {s}: {codes[s]} (len={len(codes[s])})')
    print(f'\nTotal encoded length (bits): {total_bits}')
