def generate_hanoi_moves(n, source='A', auxiliary='B', target='C'):
    """Return list of moves to solve Tower of Hanoi for n disks.

    Each move is a tuple (from, to).
    """
    moves = []

    def _hanoi(k, src, aux, dst):
        if k <= 0:
            return
        if k == 1:
            moves.append((src, dst))
            return
        _hanoi(k - 1, src, dst, aux)
        moves.append((src, dst))
        _hanoi(k - 1, aux, src, dst)

    _hanoi(n, source, auxiliary, target)
    return moves


def simulate_hanoi_steps(n, source='A', auxiliary='B', target='C'):
    """Simulate the pegs and return a list of states after each move.

    Each state is a dict: { 'A': [...], 'B': [...], 'C': [...] } with lists of disk sizes (1..n), 1 = smallest.
    The bottom of a peg is the end of the list.
    """
    moves = generate_hanoi_moves(n, source, auxiliary, target)
    # initialize pegs
    pegs = {source: list(range(n, 0, -1)), auxiliary: [], target: []}
    states = [ {k: v.copy() for k, v in pegs.items()} ]

    for frm, to in moves:
        if not pegs[frm]:
            raise RuntimeError(f"Invalid move from empty peg {frm}")
        disk = pegs[frm].pop()
        pegs[to].append(disk)
        states.append({k: v.copy() for k, v in pegs.items()})

    return moves, states


def pretty_print_state(state):
    """Return a multi-line ASCII representation of peg state.

    Pegs are printed with the top at the top of the output.
    """
    # find max height
    max_h = max(len(s) for s in state.values())
    lines = []
    peg_names = list(state.keys())
    # produce rows from top to bottom
    for level in range(max_h - 1, -1, -1):
        row = []
        for p in peg_names:
            if level < len(state[p]):
                row.append(str(state[p][level]).center(5))
            else:
                row.append(' '.center(5))
        lines.append(' '.join(row))
    lines.append('  '.join(name.center(5) for name in peg_names))
    return "\n".join(lines)


if __name__ == '__main__':
    n = 3
    moves, states = simulate_hanoi_steps(n)
    print(f"Tower of Hanoi for n={n}, total moves: {len(moves)}")
    for i, (m, s) in enumerate(zip(moves, states[1:]), start=1):
        print(f"Move {i}: {m[0]} -> {m[1]}")
        print(pretty_print_state(s))
        print()
