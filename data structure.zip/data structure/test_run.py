from tower_of_hanoi import generate_hanoi_moves, simulate_hanoi_steps
from tree_traversals import build_tree_from_level_order, preorder, inorder, postorder, level_order


def test_hanoi():
    print('=== Tower of Hanoi (n=3) ===')
    moves, states = simulate_hanoi_steps(3)
    print(f'Total moves: {len(moves)}')
    for i, ((frm, to), state) in enumerate(zip(moves, states[1:]), start=1):
        print(f'Move {i}: {frm} -> {to}')
        print(state)
    print()


def test_traversals():
    print('=== Tree Traversals (default tree: 1-31) ===')
    lst = list(range(1, 32))
    root = build_tree_from_level_order(lst)
    print('Level-order:', level_order(root))
    print('Pre-order :', preorder(root))
    print('In-order  :', inorder(root))
    print('Post-order:', postorder(root))


if __name__ == '__main__':
    test_hanoi()
    test_traversals()
