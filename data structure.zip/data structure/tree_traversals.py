from collections import deque


class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

    def __repr__(self):
        return f"Node({self.value!r})"


def preorder(root):
    result = []

    def _pre(node):
        if not node:
            return
        result.append(node.value)
        _pre(node.left)
        _pre(node.right)

    _pre(root)
    return result


def inorder(root):
    result = []

    def _in(node):
        if not node:
            return
        _in(node.left)
        result.append(node.value)
        _in(node.right)

    _in(root)
    return result


def postorder(root):
    result = []

    def _post(node):
        if not node:
            return
        _post(node.left)
        _post(node.right)
        result.append(node.value)

    _post(root)
    return result


def level_order(root):
    if not root:
        return []
    q = deque([root])
    order = []
    while q:
        node = q.popleft()
        order.append(node.value)
        if node.left:
            q.append(node.left)
        if node.right:
            q.append(node.right)
    return order


def build_tree_from_level_order(lst):
    """Build binary tree from level-order list where None means missing node.

    Example: ['A','B','C',None,'D']
    """
    if not lst:
        return None
    nodes = [None if v is None else Node(v) for v in lst]
    child_index = 1
    for i in range(len(nodes)):
        node = nodes[i]
        if node is None:
            continue
        if child_index < len(nodes):
            node.left = nodes[child_index]
            child_index += 1
        if child_index < len(nodes):
            node.right = nodes[child_index]
            child_index += 1
    return nodes[0]


if __name__ == '__main__':
    # Example tree: complete binary tree with nodes 1..31 (matches provided image)
    lst = list(range(1, 32))
    root = build_tree_from_level_order(lst)
    print('Preorder:', preorder(root))
    print('Inorder :', inorder(root))
    print('Postorder:', postorder(root))
    print('Level   :', level_order(root))
